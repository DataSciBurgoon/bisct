package application;

public interface ControlledScreen {
	
	public void setScreenParent(ScreensController screenPage);

}
