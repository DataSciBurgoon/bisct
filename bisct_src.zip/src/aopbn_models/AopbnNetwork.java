package aopbn_models;

public interface AopbnNetwork {

}
